#!/bin/bash

export PATH="/usr/local/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin:$PATH"

LOG=/tmp/auto_zip_webp.log
exec >> "$LOG" 2>&1
echo "===== $(date) ====="
echo "ARGS: $@"

for zip_path in "$@"; do
    if [[ "$zip_path" != *.zip ]]; then
        echo "Skipping (not a zip): $zip_path"
        continue
    fi

    cd "$(dirname "$zip_path")" || { echo "Cannot cd to $(dirname "$zip_path")"; exit 1; }
    zip_name=$(basename "$zip_path")
    folder_name="${zip_name%.zip}"

    echo "Processing: $zip_name"

    # 1. Unpack
    mkdir -p "$folder_name"
    if ! ditto -xk "$zip_path" "$folder_name"; then
        echo "❌ Failed to unpack $zip_name"
        continue
    fi

    # 2. Run conversion script
    SCRIPT="./png_to_webp.sh"

    if [[ ! -f "$SCRIPT" ]]; then
        echo "❌ Script not found: $(pwd)/$SCRIPT"
    else
        echo "✅ Running: $SCRIPT $folder_name"
        bash "$SCRIPT" "$folder_name"
        echo "Exit code: $?"
    fi

    # 3. Repack
    echo "Repacking $folder_name into $zip_name"
    ditto -ck --sequesterRsrc --keepParent "$folder_name" "$zip_path"

    # 4. Remove unpacked folder
    if [[ -n "$folder_name" && -d "$folder_name" ]]; then
        echo "Removing folder $folder_name"
        rm -rf "./$folder_name"
    else
        echo "⚠️ Folder $folder_name not found, skipping removal"
    fi

    echo "✅ Done: $zip_name"
done